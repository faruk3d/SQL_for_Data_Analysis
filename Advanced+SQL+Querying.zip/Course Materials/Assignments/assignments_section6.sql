-- Connect to database


-- ASSIGNMENT 1: Duplicate values

-- View the students data


-- Create a column that counts the number of times a student appears in the table


-- Return student ids, names and emails, excluding duplicates students


-- ASSIGNMENT 2: Min / max value filtering

-- View the students and student grades tables


-- For each student, return the classes they took and their final grades

        
-- Return each student's top grade and corresponding class

                    
-- ASSIGNMENT 3: Pivoting

-- Combine the students and student grades tables

        
-- View only the columns of interest

        
-- Pivot the grade_level column

        
-- Update the values to be final grades


-- Create the final summary table


-- ASSIGNMENT 4: Rolling calculations

-- Calculate the total sales each month


-- Add on the cumulative sum and 6 month moving average


