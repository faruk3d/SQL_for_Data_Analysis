-- Connect to database


-- ASSIGNMENT 1: Numeric functions

-- Calculate the total spend for each customer


-- Put the spend into bins of $0-$10, $10-20, etc.


-- Number of customers in each spend bin


-- ASSIGNMENT 2: Datetime functions

-- Extract just the orders from Q2 2024


-- Add a column called ship_date that adds 2 days to each order date


-- ASSIGNMENT 3: String functions

-- View the current factory names and product IDs


-- Remove apostrophes and replace spaces with hyphens


-- Create new ID column called factory_product_id


-- ASSIGNMENT 4: Pattern matching

-- View the product names


-- Only extract text after the hyphen for Wonka Bars


-- Alternative using substrings


-- ASSIGNMENT 5: Null functions

-- View the columns of interest


-- Replace NULL values with Other


-- Find the most common division for each factory


-- Replace NULL values with top division for each factory


-- Replace division with Other value and top division


